const CONFIG = {
  // 음향 효과 설정
  audio: {
    enabled: true,
    volume: 0.7,
    sounds: {
      notification: './mp3/new-notification-09-352705.mp3',    // 일반 액션 (청소년/성인 선택, 멘토 조언, 다시하기)
      result: './mp3/decidemp3-14575.mp3',                    // 결과 확인 (나의 투자성향 결과보기)
      select: './mp3/bubble-pop-06-351337.mp3',               // 질문 선택 (선택지 클릭)
      next: './mp3/ui-sounds-pack-2-sound-4-358895.mp3'       // 다음 질문 (다음 버튼)
    }
  },

  // 퀴즈 질문 데이터 (quiz.txt 기준)
  quiz: {
    youth: [
      {
        id: 'y1',
        text: '투자한 돈을 언제 다시 사용할 계획인가요?',
        choices: [
          { id: 'a', text: '1년 안에 쓸 예정이에요', score: 1 },
          { id: 'b', text: '2~3년 후에 쓸 예정이에요', score: 2 },
          { id: 'c', text: '5년 이상 쓸 계획이 없어요', score: 3 },
          { id: 'd', text: '10년 이상 묻어둘 거예요', score: 4 }
        ]
      },
      {
        id: 'y2',
        text: '투자는 어떤 마음으로 하고 싶나요?',
        choices: [
          { id: 'a', text: '빨리 돈을 벌고 싶어요', score: 1 },
          { id: 'b', text: '천천히 조금씩 늘려가고 싶어요', score: 2 },
          { id: 'c', text: '아주 오래 기다려서 많이 늘리고 싶어요', score: 3 },
          { id: 'd', text: '언제 써야 할지 모르겠어요', score: 4 }
        ]
      },
      {
        id: 'y3',
        text: '투자를 하는 이유는 무엇인가요?',
        choices: [
          { id: 'a', text: '용돈을 더 많이 모으고 싶어요', score: 1 },
          { id: 'b', text: '비싼 물건을 사고 싶어요', score: 2 },
          { id: 'c', text: '나중에 집을 사고 싶어요', score: 3 },
          { id: 'd', text: '나이 들어서 쓸 돈을 모으고 싶어요', score: 4 }
        ]
      },
      {
        id: 'y4',
        text: '투자로 얼마나 돈이 늘어나면 좋겠나요?',
        choices: [
          { id: 'a', text: '원금만 안 잃으면 돼요', score: 1 },
          { id: 'b', text: '1년에 3~5% 정도 늘어나면 만족해요', score: 2 },
          { id: 'c', text: '1년에 10% 정도 늘어나면 좋겠어요', score: 3 },
          { id: 'd', text: '1년에 20% 이상 많이 늘어나면 좋겠어요', score: 4 }
        ]
      },
      {
        id: 'y5',
        text: '매달 들어오는 돈(용돈, 월급 등) 중에서 얼마나 투자할 수 있나요?',
        choices: [
          { id: 'a', text: '거의 투자할 돈이 없어요', score: 1 },
          { id: 'b', text: '조금씩만 투자할 수 있어요', score: 2 },
          { id: 'c', text: '꽤 많이 투자할 수 있어요', score: 3 },
          { id: 'd', text: '아주 많이 투자할 수 있어요', score: 4 }
        ]
      },
      {
        id: 'y6',
        text: '갑자기 돈이 필요할 때 어떻게 하겠어요?',
        choices: [
          { id: 'a', text: '투자한 돈을 빼서 써야 해요', score: 1 },
          { id: 'b', text: '다른 곳에서 돈을 빌려야 해요', score: 2 },
          { id: 'c', text: '따로 모아둔 돈이 있어요', score: 3 },
          { id: 'd', text: '충분한 비상금이 있어서 걱정 없어요', score: 4 }
        ]
      },
      {
        id: 'y7',
        text: '투자한 100만 원이 80만 원으로 줄어들면 어떻게 하겠어요?',
        choices: [
          { id: 'a', text: '너무 무서워서 바로 그만둘 거예요', score: 1 },
          { id: 'b', text: '걱정되지만 조금 더 기다려볼 거예요', score: 2 },
          { id: 'c', text: '괜찮아요, 다시 오를 때까지 기다릴 거예요', score: 3 },
          { id: 'd', text: '기회다! 더 사겠어요', score: 4 }
        ]
      },
      {
        id: 'y8',
        text: '투자에서 가장 중요한 것은 무엇인가요?',
        choices: [
          { id: 'a', text: '절대 돈을 잃으면 안 돼요', score: 1 },
          { id: 'b', text: '조금 잃어도 괜찮지만 안전이 중요해요', score: 2 },
          { id: 'c', text: '돈을 잃을 수도 있지만 많이 벌 수 있으면 좋아요', score: 3 },
          { id: 'd', text: '많이 잃어도 상관없어요, 대박을 노려요', score: 4 }
        ]
      },
      {
        id: 'y9',
        text: '투자에 대해 얼마나 알고 있나요?',
        choices: [
          { id: 'a', text: '투자가 뭔지 잘 모르겠어요', score: 1 },
          { id: 'b', text: '저금과 투자의 차이 정도는 알아요', score: 2 },
          { id: 'c', text: '주식, 펀드 같은 것들에 대해 알아요', score: 3 },
          { id: 'd', text: '투자에 대해 많이 공부했어요', score: 4 }
        ]
      },
      {
        id: 'y10',
        text: '투자 경험은 어느 정도인가요?',
        choices: [
          { id: 'a', text: '한 번도 투자해본 적이 없어요', score: 1 },
          { id: 'b', text: '적금이나 예금만 해봤어요', score: 2 },
          { id: 'c', text: '펀드나 주식을 조금 해봤어요', score: 3 },
          { id: 'd', text: '여러 가지 투자를 많이 해봤어요', score: 4 }
        ]
      }
    ],
    adult: [
      {
        id: 'a1',
        text: '투자 자금의 사용 시기는 언제로 계획하고 계신가요?',
        choices: [
          { id: 'a', text: '1년 이내 사용할 계획입니다', score: 1 },
          { id: 'b', text: '2~3년 후 사용할 예정입니다', score: 2 },
          { id: 'c', text: '5년 이상 보유할 예정입니다', score: 3 },
          { id: 'd', text: '10년 이상 장기 투자할 계획입니다', score: 4 }
        ]
      },
      {
        id: 'a2',
        text: '투자에 임하는 기본적인 태도는 어떤가요?',
        choices: [
          { id: 'a', text: '단기간에 수익을 얻고 싶습니다', score: 1 },
          { id: 'b', text: '안정적으로 자산을 늘리고 싶습니다', score: 2 },
          { id: 'c', text: '장기적인 성장을 기대하며 투자합니다', score: 3 },
          { id: 'd', text: '아직 목표 시점이 정해지지 않았습니다', score: 4 }
        ]
      },
      {
        id: 'a3',
        text: '투자 목적은 무엇인가요?',
        choices: [
          { id: 'a', text: '여유 자금을 모으기 위해서입니다', score: 1 },
          { id: 'b', text: '고가의 물품(차, 가전 등) 구매를 위한 자금 마련입니다', score: 2 },
          { id: 'c', text: '주택 마련 등 중장기 목표 자금입니다', score: 3 },
          { id: 'd', text: '은퇴 이후 자금 준비를 위한 장기 자산 운용입니다', score: 4 }
        ]
      },
      {
        id: 'a4',
        text: '기대하는 수익률은 어느 정도인가요?',
        choices: [
          { id: 'a', text: '원금 손실 없이 보존되면 충분합니다', score: 1 },
          { id: 'b', text: '연 3~5% 수준의 안정적인 수익이면 좋겠습니다', score: 2 },
          { id: 'c', text: '연 10% 수준의 수익을 기대합니다', score: 3 },
          { id: 'd', text: '연 20% 이상의 높은 수익을 기대합니다', score: 4 }
        ]
      },
      {
        id: 'a5',
        text: '매달 소득 중 투자 가능한 금액은 어느 정도인가요?',
        choices: [
          { id: 'a', text: '투자할 여유가 거의 없습니다', score: 1 },
          { id: 'b', text: '소액(5~10만 원)만 정기적으로 투자할 수 있습니다', score: 2 },
          { id: 'c', text: '일정 금액을 지속적으로 투자할 수 있습니다', score: 3 },
          { id: 'd', text: '고정적으로 상당 금액을 투자할 수 있습니다', score: 4 }
        ]
      },
      {
        id: 'a6',
        text: '긴급 자금이 필요할 경우 어떻게 하시겠습니까?',
        choices: [
          { id: 'a', text: '투자금을 회수해서 사용해야 합니다', score: 1 },
          { id: 'b', text: '외부에서 자금을 조달해야 합니다 (대출 등)', score: 2 },
          { id: 'c', text: '별도로 준비한 비상금이 있습니다', score: 3 },
          { id: 'd', text: '충분한 유동성 자산을 확보해두었습니다', score: 4 }
        ]
      },
      {
        id: 'a7',
        text: '주식 투자금 100만 원이 80만 원으로 줄어들면 어떻게 하시겠습니까?',
        choices: [
          { id: 'a', text: '손실이 두려워 바로 매도하겠습니다', score: 1 },
          { id: 'b', text: '우려되지만 조금 더 지켜보겠습니다', score: 2 },
          { id: 'c', text: '회복 가능성을 믿고 유지하겠습니다', score: 3 },
          { id: 'd', text: '하락 시 추가 매수를 고려하겠습니다', score: 4 }
        ]
      },
      {
        id: 'a8',
        text: '투자 시 가장 중요하게 생각하는 것은 무엇인가요?',
        choices: [
          { id: 'a', text: '절대 손실이 없어야 합니다', score: 1 },
          { id: 'b', text: '안전성을 최우선으로 생각합니다', score: 2 },
          { id: 'c', text: '수익성과 안정성을 균형 있게 고려합니다', score: 3 },
          { id: 'd', text: '높은 수익을 위해 어느 정도 손실도 감수할 수 있습니다', score: 4 }
        ]
      },
      {
        id: 'a9',
        text: '투자에 대한 이해 수준은 어느 정도인가요?',
        choices: [
          { id: 'a', text: '투자의 개념이 익숙하지 않습니다', score: 1 },
          { id: 'b', text: '저축과 투자의 차이 정도는 알고 있습니다', score: 2 },
          { id: 'c', text: '주식, 펀드 등 기본적인 상품에 대해 압니다', score: 3 },
          { id: 'd', text: '자산 운용 전반에 대해 이해도가 높습니다', score: 4 }
        ]
      },
      {
        id: 'a10',
        text: '실제 투자 경험은 어느 정도인가요?',
        choices: [
          { id: 'a', text: '아직 투자해 본 적이 없습니다', score: 1 },
          { id: 'b', text: '예·적금 등 안전자산 위주로 운용했습니다', score: 2 },
          { id: 'c', text: '주식이나 펀드 등에 일부 투자한 경험이 있습니다', score: 3 },
          { id: 'd', text: '다양한 금융상품에 적극적으로 투자해왔습니다', score: 4 }
        ]
      }
    ]
  },

  // 결과 유형 데이터 (quiz.txt 기준: 청소년 1-4, 성인 5-8)
  results: {
    // 청소년용 결과 (result_1~4)
    1: {
      type: '안전 우선형',
      minScore: 10,
      maxScore: 17,
      userType: 'youth',
      bgClass: '',
      description: '느리지만 안전하게 가는 거북이처럼! <span class="cSecondary">안전한 투자</span>를 좋아해요.<br/>장점은 돈을 잃을 위험이 적지만, 너무 안전만 추구하면 돈을 불리는데 시간이 오래 걸릴 수 있어요. <br/><span class="cSecondary">은행 예금, 적금부터 시작</span>해서 <span class="cSecondary">원금 보장 상품 위주로 투자를 시작</span>할 수 있어요.',
      mentor: {
        name: '벤저민 그레이엄',
        tag: '#가치투자의 아버지 #월가의 스승',
        image: 'profile_1.png',
        quote: '나는 대공황을 겪으면서 깨달았네. 이 시장은 언제든 흔들릴 수 있지. 그래서 나는 항상 <span class="underline">"안전마진"을 확보하지 않으면 절대 투자하지 않았다네.</span> 시장이 불확실할수록 방어적인 자산을 담고, 주가가 아닌 "가치"를 보게나.'
      }
    },
    2: {
      type: '안전 추구형',
      minScore: 18,
      maxScore: 25,
      userType: 'youth',
      bgClass: '',
      description: '안정성을 기반으로 천천히 성장하는 투자자! <span class="cSecondary">저위험 자산</span>을 선호하면서도 약간의 수익을 추구해요.<br/>채권, MMF 등 <span class="cSecondary">중저위험 상품</span>으로 포트폴리오를 구성하고, <span class="cSecondary">장기적인 관점</span>에서 투자하는 것이 좋아요.',
      mentor: {
        name: '워런 버핏',
        tag: '#장기투자의 신',
        image: 'profile_3.png',
        quote: '좋은 기업을 적정 가격에 사서 <span class="underline">평생 보유하는 것</span>이 최고의 전략이네. 단기 변동에 흔들리지 말고, 기업의 본질적 가치를 보게나. 시간이 지나면 가치는 결국 인정받는다네.'
      }
    },
    3: {
      type: '위험 중립형',
      minScore: 26,
      maxScore: 33,
      userType: 'youth',
      bgClass: '',
      description: '리스크와 수익의 균형을 추구하는 현명한 투자자! <span class="cSecondary">분산투자</span>를 통해 위험을 관리하면서 적절한 수익을 노려요.<br/>주식과 채권을 <span class="cSecondary">적절히 배분</span>하고, 정기적인 <span class="cSecondary">리밸런싱</span>으로 포트폴리오를 관리하세요.',
      mentor: {
        name: '피터 린치',
        tag: '#월가의 영웅',
        image: 'profile_4.png',
        quote: '<span class="underline">일상에서 좋은 투자 아이디어를 찾을 수 있네.</span> 자주 가는 매장, 즐겨 쓰는 제품을 만드는 회사를 연구해보게. 10배주는 멀리 있지 않다네.'
      }
    },
    4: {
      type: '적극 투자형',
      minScore: 34,
      maxScore: 40,
      userType: 'youth',
      bgClass: '',
      description: '높은 수익을 위해 적극적으로 리스크를 감수하는 투자자! <span class="cSecondary">고위험-고수익</span> 전략을 추구해요.<br/>성장주, 테마주, 해외 투자 등 <span class="cSecondary">다양한 기회</span>를 포착하고, <span class="cSecondary">적극적인 매매</span>로 수익을 극대화하세요.',
      mentor: {
        name: '조지 소로스',
        tag: '#금융의 연금술사',
        image: 'profile_5.png',
        quote: '시장은 항상 틀리고, <span class="underline">그 틀림을 찾아내는 것이 기회</span>라네. 대중이 공포에 떨 때 매수하고, 탐욕스러울 때 매도하게. 하지만 리스크 관리는 철저히 해야 하네.'
      }
    },
    
    // 성인용 결과 (result_5~8)
    5: {
      type: '안전 우선형',
      minScore: 10,
      maxScore: 17,
      userType: 'adult',
      bgClass: 'bg_ter2',
      description: '손실을 극도로 꺼리고 투자금 보전을 최우선으로 생각하시는군요. <br/>투자 경험이 거의 없거나 투자에 대한 자신감과 정보가 부족한 상태입니다. <br/>투자 비중보다는 저축 및 금융 안전망 확보가 먼저 이루어져야 하므로 <span class="cSecondary">정기예금, MMF, 국채 또는 원금보장형 ELS 등을 추천</span>합니다.',
      mentor: {
        name: '벤저민 그레이엄',
        tag: '#가치투자의 아버지 #월가의 스승',
        image: 'profile_1.png',
        quote: '투자는 철저히 자신을 지키는 행위이며, 절대 도박이 되어서는 안 된다네. <br/><span class="underline">장기적으로 금융 문해력을 키워, 예산 일부를 안정적인 <br/>배당주 펀드 등으로 천천히 노출시켜 보게나.</span> <br/>원칙은 "안정 + 점진적 학습"인 걸 잊지 마시게.'
      }
    },
    6: {
      type: '안전 추구형',
      minScore: 18,
      maxScore: 25,
      userType: 'adult',
      bgClass: 'bg_ter2',
      description: '손실 가능성은 우려하지만 일정 수준의 수익도 기대하시는군요. <br/> 투자에 대해 학습 의지가 있으며 자산 배분의 중요성을 인식하고 있습니다. <br/>분산 투자를 기반으로 한 혼합형 자산 구성을 추천하며 목표 중심(주택 마련, 자녀 교육 등)의 자산 운용이 이루어져야 합니다. <br/>적합한 상품으로는  <span class="cSecondary">채권형 펀드, 안전형 ETF, TDF</span> 등이 있고  배당주와 우량주 중심으로 포트폴리오를 구성하는 것도 고려해보시면 좋습니다.',
      mentor: {
        name: '존 보글',
        tag: '#인덱스 펀드 창시자 #월가의 성자',
        image: 'profile_2.png',
        quote: '복잡한 전략은 필요 없습니다. <br/><span class="underline">낮은 비용, 분산된 투자, 그리고 장기 보유가 핵심인 걸 <br/>잊지 마세요.</span> 너무 빠르게 수익을 추구하지 말고, 꾸준한 <br/>지출 통제와 함께 <span class="underline">자동화된 투자 습관을 구축</span>해야 합니다. <br/>이 습관은 지루하지만 강력한 전략이 될 것입니다.'
      }
    },
    7: {
      type: '위험 중립형',
      minScore: 26,
      maxScore: 33,
      userType: 'adult',
      bgClass: 'bg_ter2',
      description: '중장기 자산 증식 목표를 갖고 계시는군요. <br/><span class="cSecondary">수익성과 손실 리스크 사이에서 균형을 잡는 걸 중요</span>하게 생각하고 있습니다.<br/>다양한 자산에 대한 이해와 관리가 가능하므로 주식과 채권 비중을 6:4 또는 7:3 정도 유지하는 것이 좋습니다. <br/><span class="cSecondary">우량주와 중소형 성장주 혼합 포트폴리오를 추천</span>하며 글로벌 <span class="cSecondary">ETF, 리츠(REITs) 등을 고려</span>해볼 수 있습니다.',
      mentor: {
        name: '피터 린치',
        tag: '#월가의 영웅 #월가를 이긴 전설의 펀드매니저',
        image: 'profile_4.png',
        quote: '<span class="underline">자신이 이해하는 기업에 투자하고, 스스로 조사하는 <br/>습관이 중요</span>합니다. <br/>기업의 가치와 흐름을 파악할 수 있다면, <span class="underline">일상에서 보이는 기회가 최고의 정보</span>입니다. <br/>장기적인 관점으로 본인의 투자 기준을 만들어보세요.'
      }
    },
    8: {
      type: '적극 투자형',
      minScore: 34,
      maxScore: 40,
      userType: 'adult',
      bgClass: 'bg_ter2',
      description: ' 높은 수익률을 목표로 하며 손실에 대한 내성도 강하시네요. <br/>이미 <span class="cSecondary">투자에 대한 지식과 경험이 풍부</span>해서 시장 흐름을 빠르게 읽고 과감한 의사결정을 하실 수 있는 기반이 되어 있습니다. <br/> 수익률 극대화를 위한 적극적 자산 운용을 추천드립니다. <span class="cSecondary">트렌드 기반의 테마 투자</span> 또는 <span class="cSecondary">글로벌 분산</span> 등을 활용하면서 <span class="cSecondary">리스크 헷징</span>과 <span class="cSecondary">종목 리밸런싱을 병행</span>하는 전략이 필요해요.',
      mentor: {
        name: '마크 모비우스',
        tag: '#신흥국 투자의 대부',
        image: 'profile_6.png',
        quote: '내가 세계 곳곳의 신흥국 시장에 발을 들일 때가 생각나는군요. 정보도 적고, 정치적 불확실성도 커서 모두가 말렸죠. 하지만 나는 그 리스크 속에 숨겨진 기회를 보았고, 직접 <br/> 현장에 뛰어 들어 하나하나 확인해보고 분석했던 기억이 나는군요. <br/><span class="underline">두려움이 있는 곳에 기회가 있고, 행동하는 자에게 수익이 따릅니다. </span> 그러나 그 행동은 반드시 <span class="underline">지식과 분석, 그리고 <br/>준비된 태도 위에 있어야 합니다.</span>'
      }
    }
  },

  // 멘토 데이터
  mentors: {
    youth: [
      { id: 1, name: '벤저민 그레이엄', tag: '가치투자의 아버지', image: 'profile_1.png', class: 'ty2' },
      { id: 3, name: '워런 버핏', tag: '장기투자의 신', image: 'profile_3.png' },
      { id: 4, name: '피터 린치', tag: '월가의 영웅', image: 'profile_4.png' },
      { id: 5, name: '조지 소로스', tag: '금융의 연금술사', image: 'profile_5.png' }
    ],
    adult: [
      { id: 1, name: '벤저민 그레이엄', tag: '가치투자의 아버지', image: 'profile_1.png', class: 'ty2' },
      { id: 2, name: '존 보글', tag: '인덱스 펀드 창시자', image: 'profile_2.png' },
      { id: 4, name: '피터 린치', tag: '월가의 영웅', image: 'profile_4.png' },
      { id: 6, name: '마크 모비우스', tag: '신흥국 투자의 대부', image: 'profile_6.png' }
    ]
  },

  // 멘토링 내용
  mentoring: {
    1: {
      name: '벤저민 그레이엄',
      title: '가치투자의 아버지',
      subtitle: '안전마진의 철학',
      image: 'profile_1_b.png',
      content: `
        <p class="body_01cDGray">투자의 첫 원칙은 <span class="cSecondary">원금을 잃지 않는 것</span>이네.</p>
        <p class="body_02cDGray">
          내가 대공황을 겪으며 배운 가장 큰 교훈은 '안전마진'의 중요성이었네. 
          아무리 좋은 기업이라도 비싸게 사면 손실을 볼 수 있지. 
          <br/><br/>
          <span class="cSecondary">내재가치보다 싸게 살 때만 투자하게.</span> 
          시장이 공포에 빠졌을 때가 기회라네. 
          남들이 팔 때 사고, 남들이 살 때 파는 용기가 필요하지.
          <br/><br/>
          투자와 투기의 차이를 명확히 구분하게. 
          <span class="underline">철저한 분석, 원금 보전, 적정 수익</span> - 이 세 가지를 갖춘 것만이 진정한 투자라네.
        </p>
      `
    },
    2: {
      name: '존 보글',
      title: '인덱스펀드의 창시자',
      subtitle: '단순함의 미학',
      image: 'profile_2_b.png',
      content: `
        <p class="body_01cDGray"><span class="cSecondary">비용을 아끼는 것</span>이 수익을 높이는 가장 확실한 방법이네.</p>
        <p class="body_02cDGray">
          40년간 뱅가드를 운영하며 깨달은 진리는 '단순함이 최고'라는 것이네. 
          복잡한 전략, 잦은 매매, 높은 수수료는 모두 수익을 갉아먹지.
          <br/><br/>
          <span class="cSecondary">저비용 인덱스 펀드에 꾸준히 투자하게.</span> 
          시장을 이기려 하지 말고, 시장과 함께 가는 것이 지혜라네. 
          시간이 지나면 복리의 마법이 자네를 부자로 만들어줄 것이네.
          <br/><br/>
          <span class="underline">Don't look for the needle in the haystack. Just buy the haystack!</span>
          건초더미에서 바늘을 찾지 말고, 건초더미를 통째로 사게나.
        </p>
      `
    },
    3: {
      name: '워런 버핏',
      title: '오마하의 현인',
      subtitle: '장기투자의 정석',
      image: 'profile_3_b.png',
      content: `
        <p class="body_01cDGray"><span class="cSecondary">시간은 좋은 기업의 친구</span>이고, 평범한 기업의 적이라네.</p>
        <p class="body_02cDGray">
          60년 투자 인생에서 배운 것은 '인내'의 가치라네. 
          좋은 기업을 적정 가격에 사서 평생 보유하는 것, 이것이 내 전략의 핵심이지.
          <br/><br/>
          <span class="cSecondary">이해할 수 없는 것에는 투자하지 마라.</span> 
          자네가 잘 아는 기업, 10년 후에도 있을 기업에 투자하게. 
          코카콜라, 질레트, 아메리칸 익스프레스 - 이런 기업들이 나를 부자로 만들었네.
          <br/><br/>
          주가는 단기적으로는 투표기계지만, <span class="underline">장기적으로는 저울</span>이라네. 
          시장의 미스터 마켓이 제시하는 가격에 현혹되지 말고, 기업의 진짜 가치를 보게나.
        </p>
      `
    },
    4: {
      name: '피터 린치',
      title: '월가의 영웅',
      subtitle: '텐배거의 비밀',
      image: 'profile_4_b.png',
      content: `
        <p class="body_01cDGray"><span class="cSecondary">평범한 사람도 전문가를 이길 수 있다</span>네.</p>
        <p class="body_02cDGray">
          13년간 마젤란 펀드를 운용하며 연평균 29%의 수익을 올렸네. 
          비결은 간단하지 - 일상에서 투자 아이디어를 찾는 것이라네.
          <br/><br/>
          <span class="cSecondary">자네가 아는 것에 투자하라.</span> 
          자주 가는 매장, 좋아하는 제품, 늘어나는 고객 - 이런 신호들을 놓치지 마게. 
          던킨도너츠, 월마트, 홈디포 같은 10배주들은 모두 우리 주변에 있었네.
          <br/><br/>
          기업을 6가지로 분류하게 - <span class="underline">성장주, 우량주, 자산주, 회복주, 경기순환주, 급성장주</span>. 
          각각의 특성을 이해하고 적절한 시기에 투자하는 것이 중요하네.
        </p>
      `
    },
    5: {
      name: '조지 소로스',
      title: '금융의 연금술사',
      subtitle: '재귀성 이론의 대가',
      image: 'profile_5_b.png',
      content: `
        <p class="body_01cDGray"><span class="cSecondary">시장은 항상 틀린다</span> - 그것이 기회라네.</p>
        <p class="body_02cDGray">
          1992년 파운드화 공격으로 하루에 10억 달러를 벌었네. 
          비결은 '재귀성 이론' - 시장 참여자의 인식이 현실을 만들고, 그 현실이 다시 인식을 바꾸는 순환 구조를 이해하는 것이지.
          <br/><br/>
          <span class="cSecondary">틀렸다면 빨리 인정하고 빠져나오게.</span> 
          나는 항상 틀릴 수 있다는 전제하에 투자하네. 
          그래서 손절이 빠르고, 포지션 조정이 유연하지.
          <br/><br/>
          <span class="underline">버블을 찾고, 올라타고, 터지기 전에 내리는 것</span> - 
          위험해 보이지만 이것이 가장 큰 수익을 내는 방법이라네. 
          물론 리스크 관리는 철저히 해야 하네.
        </p>
      `
    },
    6: {
      name: '제시 리버모어',
      title: '월가의 큰 곰',
      subtitle: '타이밍의 마스터',
      image: 'profile_6_b.png',
      content: `
        <p class="body_01cDGray"><span class="cSecondary">시장은 결코 틀리지 않는다</span> - 틀린 것은 의견이라네.</p>
        <p class="body_02cDGray">
          1929년 대공황을 예측하고 공매도로 1억 달러를 벌었네. 
          하지만 4번의 파산도 겪었지. 그 과정에서 배운 교훈들을 전하고 싶네.
          <br/><br/>
          <span class="cSecondary">큰 돈은 매매가 아니라 기다림에서 나온다.</span> 
          확실한 신호가 올 때까지 기다리고, 확신이 들 때 크게 베팅하게. 
          하지만 틀렸다면 자존심 버리고 즉시 손절하게.
          <br/><br/>
          <span class="underline">추세를 따르되, 전환점을 놓치지 마라.</span> 
          상승장에서는 선도주를, 하락장에서는 약세주를 공략하게. 
          그리고 절대, 절대로 평균 매수는 하지 마라.
        </p>
      `
    },
    7: {
      name: '레이 달리오',
      title: '헤지펀드의 제왕',
      subtitle: '원칙의 설계자',
      image: 'profile_3_b.png',
      content: `
        <p class="body_01cDGray"><span class="cSecondary">실패는 발전의 원동력</span>이라네.</p>
        <p class="body_02cDGray">
          브리지워터를 세계 최대 헤지펀드로 키운 비결은 '원칙'이었네. 
          모든 투자 결정을 원칙에 따라 시스템화하고, 실패에서 배우며 진화했지.
          <br/><br/>
          <span class="cSecondary">올웨더 포트폴리오를 만들게.</span> 
          경제는 4계절처럼 순환하네 - 성장기, 침체기, 인플레이션, 디플레이션. 
          각 시기에 잘 작동하는 자산을 균형있게 배분하면 어떤 날씨에도 견딜 수 있지.
          <br/><br/>
          <span class="underline">극단적 투명성과 건설적 비판</span>이 성공의 열쇠라네. 
          자신의 실수를 인정하고, 다른 사람의 비판을 겸허히 받아들이게. 
          그것이 더 나은 투자자가 되는 길이네.
        </p>
      `
    },
    6: {
      name: '마크 모비우스',
      title: '신흥국 투자의 대부',
      subtitle: '글로벌 투자의 개척자',
      image: 'profile_6_b.png',
      content: `
        <p class="body_01cDGray"><span class="cSecondary">기회는 남들이 두려워할 때 온다</span>네.</p>
        <p class="body_02cDGray">
          40년간 신흥국 투자를 하며 깨달은 것은 '변화'가 가장 큰 기회라는 것이네. 
          경제 발전 단계에 있는 국가들은 선진국보다 훨씬 빠른 성장을 보여주지.
          <br/><br/>
          <span class="cSecondary">현지를 직접 발로 뛰며 투자하라.</span> 
          나는 투자하기 전에 반드시 현지를 방문하네. 
          숫자와 보고서로는 알 수 없는 진짜 기회와 위험을 눈으로 확인해야 하지.
          <br/><br/>
          <span class="underline">인내심과 용기, 그리고 현지화</span> - 
          신흥국 투자는 변동성이 클 수 있지만, 장기적으로는 큰 보상을 준다네. 
          현지 문화와 정치를 이해하는 것이 성공의 열쇠라네.
        </p>
      `
    },
    8: {
      name: '캐시 우드',
      title: 'ARK 인베스트 CEO',
      subtitle: '파괴적 혁신의 전도사',
      image: 'profile_6_b.png',
      content: `
        <p class="body_01cDGray"><span class="cSecondary">미래는 이미 와 있다</span> - 단지 고르게 분포되지 않았을 뿐이네.</p>
        <p class="body_02cDGray">
          5년 안에 세상을 바꿀 5가지 혁신 플랫폼을 주목하게 - 
          AI, 로봇공학, 유전자 편집, 블록체인, 우주 탐사. 
          이들이 만들 시장은 현재 글로벌 GDP를 넘어설 것이네.
          <br/><br/>
          <span class="cSecondary">단기 변동성은 장기 투자자에게 선물이라네.</span> 
          테슬라가 50% 하락했을 때 모두가 팔았지만, 나는 더 샀네. 
          혁신 기업의 가치는 5년, 10년 후에 진정으로 드러나지.
          <br/><br/>
          <span class="underline">연구에 기반한 확신, 그리고 인내</span> - 
          이것이 파괴적 혁신에 투자하는 방법이네. 
          월가의 단기 시각에 흔들리지 말고, 기술의 융합이 만들 미래를 보게나.
        </p>
      `
    }
  }
};